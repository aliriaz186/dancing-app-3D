
     <!-- BEGIN #promotions -->
        <div id="promotions" class="section-container bg-white">
            <!-- BEGIN container -->
            <div class="container">
                
                <!-- BEGIN row -->
                <div class="row row-space-10">
                    <!-- BEGIN col-6 -->
                    
                    <!-- END col-6 -->
                    <!-- BEGIN col-3 -->
                    <div class="col-md-6">
                       
                        <!-- BEGIN promotion -->
                        <div class="promotion  promotion-lg bg-silver">
                            
                            <div class="promotion-caption text-center">
                                <h4 class="promotion-title">Sample Text</h4>
                                <div class="promotion-price"><small>from</small> Price $0.00</div>
                                <p class="promotion-desc">It’s mini in a massive way.</p>
                                <a href="#" class="promotion-btn" style="color: #b74162;">View More</a>
                            </div>
                        </div>
                        <!-- END promotion -->
                    </div>
                    <!-- END col-3 -->
                  <div class="col-md-6">
                        <!-- BEGIN promotion -->

                            <div class="">
                                <img src="{{ asset('img/dance_img/img_8517.jpg')}}" alt="" />
                            </div>

                        <!-- END promotion -->
                    </div>
                </div>
                <!-- END row -->
            </div>
            <!-- END container -->
        </div>
        <!-- END #promotions -->
