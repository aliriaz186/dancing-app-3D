<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/about', function () {
    return view('about_us');
});
Route::get('/login', function () {
    return view('login');
});
Route::get('/register', function () {
    return view('register');
});
Route::get('/guide', function () {
    return view('guide_tour');
});
Route::get('/lessons/{id}', function ($id) {
    // dd(App\Video::where('section_id', $id)->get());
    return view('lessons')->with('videos', App\Video::where('section_id',$id)->get());
});
Route::get('/chart', function () {
    return view('dance_chart');
});
Route::get('/select', function () {
    return view('select_lesson')->with('lessons', DB::table('lessons')->get());
});
Route::get('/side_view', function () {
    return view('side_view');
});
Route::get('/contact', function () {
    return view('contact_us');
});
Route::get('/section/{id}', function ($id) {
    return view('section_lesson')
    ->with('sections', App\Section::where('lesson_id',$id)->get());
});
Route::get('/profile/{id}', function ($id) {
    // dd(App\User::find($id));
    return view('view_profile')->with('user',App\User::find($id));
});
Route::get('/edit_profile', function () {
    return view('edit_profile');
});
Route::get('/badge', function () {
    return view('view_badges');
});
Route::get('/notifications', function () {
    return view('view_notifications');
});
Route::get('/enviornment', function () {
    return view('dance_floor_enviornment');
});
Route::get('/faq', function () {
    return view('faq');
});

Route::get('/test',function(){
    dd(App\Section::find(2)->videos);
});

Route::post('/reset/{id}', 'AdminController@resetPassword')->name('reset');

Route::post('/user/register', 'AdminController@store')->name('user.register');
// Admin Routes
Route::group(['prefix' => 'admin'], function () {
    Auth::routes();

    Route::middleware(['isAdmin'])->group(function () {
        Route::get('/home', 'HomeController@index')->name('home');
        Route::get('/users/list', 'AdminController@index')->name('user.list');
        Route::get('/user/create', 'AdminController@create')->name('user.create');
        Route::get('/status/toggle/{id}','AdminController@statusToggle')->name('status.toggle');
        Route::post('/user/store','AdminController@store')->name('user.store');
        Route::get('/user/delete/{id}','AdminController@delete')->name('user.delete');
        Route::get('/user/profile/{id}', 'AdminController@userProfile')->name('user.profile');
        Route::post('/user/profile/store/{id}','AdminController@profileUpdate')->name('user.profile.store');
        Route::get('/user/detail/{id}','AdminController@singleUser')->name('single.user');
    });

});

