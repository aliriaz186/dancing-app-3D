<?php $__env->startSection('content'); ?>
    
<?php echo $__env->make('/_slider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('/_android_ios', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('/_picture_text', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('/_text_picture', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('/_about_us', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('/_fa', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>