
     <!-- BEGIN #promotions -->
        <div id="promotions" class="section-container" style="background: #333333 !important">
            <!-- BEGIN container -->
            <div class="container">
                
                <!-- BEGIN row -->
                <div class="row row-space-10">
                    <!-- BEGIN col-6 -->
                    
                    <!-- END col-6 -->
                    <!-- BEGIN col-3 -->
                    <div class="col-md-6">
                       
                        <!-- BEGIN promotion -->
                        <div class="promotion  promotion-lg " style="background: #333333 !important">
                            
                            <div class="promotion-caption text-center">
                                <h4 class="promotion-title" style="color: #ffffff;">Sample Text</h4>
                                <div class="promotion-price" style="color: #ffffff;"><small>from</small> Price $0.00</div>
                                <p class="promotion-desc" style="color: #ffffff;">It’s mini in a massive way.</p>
                                <a href="#" class="promotion-btn" style="color: #fbdf36;">View More</a>
                            </div>
                        </div>
                        <!-- END promotion -->
                    </div>
                    <!-- END col-3 -->
                  <div class="col-md-6">
                        <!-- BEGIN promotion -->

                            <div class="" >
                                <img src="<?php echo e(asset('img/dance_img/img_8517.jpg')); ?>" alt="" style="width: 100%;height: auto;" />
                            </div>

                        <!-- END promotion -->
                    </div>
                </div>
                <!-- END row -->
            </div>
            <!-- END container -->
        </div>
        <!-- END #promotions -->
