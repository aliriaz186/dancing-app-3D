

<?php echo $__env->make('admin.includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('admin.includes.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('admin.includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="content-wrapper">
<section class="content">
    <div class="row">
    <?php echo $__env->yieldContent('admin_main'); ?>
     </div>
</section>
</div>

<?php echo $__env->make('admin.includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('admin.includes.footer_links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



