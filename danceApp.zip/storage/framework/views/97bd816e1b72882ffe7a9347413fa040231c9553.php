<?php $__env->startSection('admin_main'); ?>
<div class="col-lg-12 col-xs-12 ">

          <div class="box">
            <div class="box-header">
              <h3 class="box-title">User List</h3>
            </div>
            <!-- /.box-header -->
             <?php if(Session::has('warn')): ?>
             <div class="alert alert-warning hidout" role="alert">
                <?php echo e(Session::get('warn')); ?>

            </div>
            <?php endif; ?>
            <?php if(Session::has('success')): ?>
          <div class="alert alert-info hidout" role="alert">
            <?php echo e(Session::get('success')); ?>

          </div>
            <?php endif; ?>

            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Username</th>
                    <th>email</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if(isset($users)): ?>
                  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($user->id); ?></td>
                    <td><?php echo e($user->username); ?></td>
                    <td>
                      <?php echo e($user->email); ?>

                    </td>
                    <td><?php if($user->is_admin): ?> <button class="btn btn-success btn-sm"> Admin</button> <?php else: ?> <button
                        class="btn btn-info btn-sm">Simple User</button> <?php endif; ?></td>
                    <td><?php if($user->block): ?> <a href="<?php echo e(route('status.toggle',['id'=>$user->id])); ?>"><button class="btn btn-danger btn-sm">Blocked</button></a> <?php else: ?> <a href="<?php echo e(route('status.toggle',['id'=>$user->id])); ?>"><button
                        class="btn btn-primary btn-sm">Active</button></a> <?php endif; ?></td>
                    <td>
                     <i class="fa fa-eye contact-detail" style="color:blue"
                     data-toggle="modal" data-target="#contactModal" data-id="<?php echo e($user->id); ?>"
                     ></i>
                     
                      
                    <a href="<?php echo e(route('user.delete',['id'=>$user->id])); ?>"> 
                       <i class="fa fa-trash" style="color:red"></i>
                    </a>
                      </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
              </table>
            </div>
            </div>
            <!-- /.box-body -->
          </div>

                  <div class="modal fade" id="contactModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg" role="document">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="exampleModalLabel">User Detail</h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <div class="modal-body" id="contact_model">
                        </div>
                      </div>
                </div>
                </div>

          <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>