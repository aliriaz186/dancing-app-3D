 <table id="order-listing" class="table">
                  <thead>
                    <tr class="bg-primary text-white">
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Username</th>
                        <th>Phone Number</th>
                        <th>Address</th>
                        <th>Designation</th>
                        <th>Status</th>
                        <th>Role</th>
                        <th>Image</th>                        

                        
                    </tr>
                  </thead>
                  <tbody>
                    <?php if(isset($data)): ?>
                    <tr>
                        <td><?php echo e($data->id); ?></td>
                        <td><?php echo e($data->profile->name); ?></td>
                        <td><?php echo e($data->email); ?></td>
                        <td><?php echo e($data->username); ?></td>
                        <td><?php echo e($data->phone_no); ?></td>
                        <td><?php echo e($data->profile->address); ?></td>
                        <td><?php echo e($data->profile->desigenation); ?></td>
                        <td>
                            <?php if(!$data->block): ?> 
                            <button class="btn btn-success">Active</button>
                            <?php else: ?><button class="btn btn-danger">Blocked</button>
                            <?php endif; ?>
                        </td>
                        <td><?php if($data->is_admin): ?> <button class="btn btn-success">Admin</button> <?php else: ?>
                        <button class="btn btn-danger">simple User</button>
                        <?php endif; ?>
                        </td>
                <td>
                    
                    <img src="<?php echo e(asset($data->profile->image)); ?>" class="rounded" alt="no image" height="30px" width="30px"></td>
                    </tr>
                <?php endif; ?>
                  </tbody>
                </table>
