 


<?php $__env->startSection('content'); ?>


        <!-- BEGIN #page-header -->
        
        <!-- BEGIN #about-us-cover -->
        <div id="about-us-cover" class="has-bg section-container">
            <!-- BEGIN cover-bg -->
            <div class="cover-bg">
                <img src="<?php echo e(asset('img/slider-3-cover.jpg')); ?>" alt="" style="width: 100%;height: auto;"/>
            </div>
            <!-- END cover-bg -->
            <!-- BEGIN container -->
            <div class="container">
                <!-- BEGIN breadcrumb -->
                <ul class="breadcrumb m-b-10 f-s-12">
                    <li><a href="#">Home</a></li>
                    <li class="active">Guide Tour</li>
                </ul>
                <!-- END breadcrumb -->
                <!-- BEGIN about-us -->
                <div class="about-us text-center">
                    <h1>Lessons</h1>
                    <p>
                     Learn dancing step by step by watching these lessons .
                    </p>
                </div>
                <!-- END about-us -->
            </div>
            <!-- END container -->
        </div>
        <!-- END #about-us-cover -->
        
        <!-- BEGIN #about-us-content -->
        <div id="about-us-content" class="section-container" style="background:#010101;">
            <!-- BEGIN container -->
            <div class="container">
                <!-- BEGIN about-us-content -->
                <div class="about-us-content">
                    <!-- BEGIN row -->
                    <hr />
                    <div style="background: " class="row">
                       <div class="col-md-12">
                        
                        <table id="data-table" class="table table-bordered" style="background: #333333">
                             
                            <thead>
                                    <tr>
                                    	<th style="color:#fbdf36;text-align: center">Sr#</th>
                                        <th style="color:#fbdf36;">Lessons</th>
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="odd gradeX">
                                        <td style="color:#fbdf36;text-align: center">1</td>
                                        <td><a href="<?php echo e(url('/section')); ?>" style="color:#ffffff;">Lesson No# 1</a></td>
                                    </tr>
                                    <tr class="odd gradeX">
                                        <td style="color:#fbdf36;text-align: center">2</td>
                                        <td><a href="<?php echo e(url('/section')); ?>" style="color:#ffffff;">Lesson No# 2</a></td>
                                    </tr>
                                    <tr class="odd gradeX">
                                        <td style="color:#fbdf36;text-align: center">3</td>
                                        <td><a href="<?php echo e(url('/section')); ?>" style="color:#ffffff;">Lesson No# 3</a></td>
                                    </tr>
                                    <tr class="odd gradeX">
                                        <td style="color:#fbdf36;text-align: center">4</td>
                                        <td ><a href="<?php echo e(url('/section')); ?>" style="color:#ffffff;">Lesson No# 4</a></td>
                                    </tr>
                                    <tr class="odd gradeX">
                                        <td style="color:#fbdf36;text-align: center">5</td>
                                        <td><a href="<?php echo e(url('/section')); ?>" style="color:#ffffff;">Lesson No# 5</a></td>
                                    </tr>
                                    <tr class="odd gradeX">
                                        <td style="color:#fbdf36;text-align: center">6</td>
                                        <td><a href="<?php echo e(url('/section')); ?>" style="color:#ffffff;">Lesson No# 6</a></td>
                                    </tr>
                                    
                                </tbody>
                                
                            </table>
                        
                    </div>
                                    
                    </div>
                    <!-- END row -->
                    <hr />
                    
                </div>
                <!-- END about-us-content -->
            </div>
            <!-- END container -->
        </div>
        <!-- END #about-us-content -->
<?php echo $__env->make('/_fa', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>        
<?php $__env->stopSection(); ?>        
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>