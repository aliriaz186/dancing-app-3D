
     <!-- BEGIN #promotions -->
        <div id="promotions" class="section-container " style="background: #010101 !important">
            <!-- BEGIN container -->
            <div class="container">
                
                <!-- BEGIN row -->
                <div class="row row-space-10"   >
                    <!-- BEGIN col-6 -->
                    <div class="col-md-6">
                        <!-- BEGIN promotion -->

                            <div class="text-right">
                                <img src="<?php echo e(asset('img/dance_img/p05n7hyj.jpg')); ?>" alt="" />
                            </div>

                        <!-- END promotion -->
                    </div>
                    <!-- END col-6 -->
                    <!-- BEGIN col-3 -->
                    <div class="col-md-6">
                       
                        <!-- BEGIN promotion -->
                        <div class="promotion  promotion-lg " style="background: #333333 !important">
                            
                            <div class="promotion-caption text-center" >
                                <h4 class="promotion-title" style="color: #ffffff;">Sample Text</h4>
                                <div class="promotion-price" style="color: #ffffff;"><small>from</small> Price 0.00</div>
                                <p class="promotion-desc" style="color: #ffffff;">Dummy Data Inserted</p>
                                <a href="#" class="promotion-btn" style="color: #fbdf36;">View More</a>
                            </div>
                        </div>
                        <!-- END promotion -->
                    </div>
                    <!-- END col-3 -->
                    
                    <!-- END col-3 -->
                </div>
                <!-- END row -->
            </div>
            <!-- END container -->
        </div>
        <!-- END #promotions -->
