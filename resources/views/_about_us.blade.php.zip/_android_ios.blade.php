    
        <!-- BEGIN #policy -->
        <div id="policy" class="section-container p-t-15 p-b-15" style="background: #333333eb !important">
            <!-- BEGIN container -->
            <div class="container">
                <!-- BEGIN row -->
                <div class="row">
                    <div class="col-md-2 col-sm-2">
                    </div>
                    <!-- BEGIN col-4 -->
                    <div class="col-md-4 col-sm-4">
                        <!-- BEGIN policy -->
                        <a href="https://www.apple.com/"><img  class="pull-right" src="{{ asset('img/apple_store.png') }}"  alt="apple_store" style="width: 170px;height: 60px;" /></a>
                        <!-- END policy -->
                    </div>
                    <!-- END col-4 -->
                    <!-- BEGIN col-4 -->
                    <div class="col-md-4 col-sm-4">
                        <!-- BEGIN policy -->
                        <a href="https://play.google.com/store/apps"><img class="pull-left" src="{{ asset('img/google_play.png') }}"  alt="google_play" style="width: 170px;height: 60px;" /></a>
                        <!-- END policy -->
                    </div>
                    <!-- END col-4 -->
                    <!-- BEGIN col-4 -->
                    <div class="col-md-2 col-sm-2">
                    </div>
                    <!-- END col-4 -->
                </div>
                <!-- END row -->
            </div>
            <!-- END container -->
        </div>
        <!-- END #policy -->