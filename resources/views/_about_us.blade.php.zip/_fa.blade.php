<div id="subscribe" class="section-container  p-t-0 p-b-0" style="background:#333333;">
    <div class="container">
        <ul class="nav navbar-nav" style="margin-left: 45%;" >
                <li><a href="https://www.facebook.com"><i class="fa fa-facebook fa-3x f-m-14" style="color:#fbdf36;"></i></a></li>
                <li><a href="https://www.youtube.com"><i class="fa fa-youtube  fa-3x f-m-14" style="color:#fbdf36;"></i></a></li>
                <li><a href="https://www.twitter.com"><i class="fa fa-twitter  fa-3x f-m-14" style="color:#fbdf36;"></i></a></li>
        </ul>
    </div>
</div>
