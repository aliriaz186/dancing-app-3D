@extends('main')


@section('content')
    
@include('/_slider')
@include('/_android_ios')
@include('/_picture_text')
@include('/_text_picture')
@include('/_about_us')
@include('/_fa')

    
@endsection
